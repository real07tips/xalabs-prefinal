<?php
require_once __DIR__ . '/../models/Socio.php';
require_once __DIR__ . '/../conexion.php';
function listarSocios($error = null) {
    global $pdo;
    $filtros = [
        'nombre'   => trim($_GET['nombre'] ?? ''),
        'email'    => trim($_GET['email'] ?? ''),
        'telefono' => trim($_GET['telefono'] ?? ''),
        'vinculo'  => trim($_GET['vinculo'] ?? ''),
    ];
    $hayFiltros = count(array_filter($filtros, 'strlen')) > 0;
    $vinculos = Socio::vinculos($pdo);
    $porPagina = 10;
    $pagina = max(1, (int)($_GET['pagina'] ?? 1));
    $totalRegistros = Socio::contar($pdo, $filtros);
    $totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
    $pagina = min($pagina, $totalPaginas);
    $socios = Socio::listar($pdo, $filtros, $porPagina, ($pagina - 1) * $porPagina);
    require __DIR__.'/../views/socios/listar.php';
}
function formCrearSocio() {
    require __DIR__.'/../views/socios/form.php';
}
function crearSocio() {
    global $pdo;
    $nombre=trim($_POST['nombre']??'');
    $vinculo=trim($_POST['vinculo']??'');
    $estado=trim($_POST['estado']??'Activo');
    $telefono=trim($_POST['telefono']??'');
    $email=trim($_POST['email']??'');
    if($email!==''&&!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error='El correo no es válido.';
        require __DIR__.'/../views/socios/form.php';
        return;
    }
    if($nombre===''||$vinculo==='') {
        $error='Nombre y vínculo son obligatorios.';
        require __DIR__.'/../views/socios/form.php';
        return;
    }
    Socio::crear($pdo, $nombre, $vinculo, $estado, $telefono, $email);
    header('Location: index.php?accion=listarSocios');
    exit;
}
function formEditarSocio() {
    global $pdo;
    $socio=Socio::buscarPorId($pdo, $_GET['id']??0);
    if(!$socio) {
        header('Location: index.php?accion=listarSocios');
        exit;
    }
    require __DIR__.'/../views/socios/form.php';
}
function editarSocio() {
    global $pdo;
    $id=(int)($_POST['id']??0);
    $socio=Socio::buscarPorId($pdo, $id);
    if(!$socio) {
        header('Location: index.php?accion=listarSocios');
        exit;
    }
    $nombre=trim($_POST['nombre']??'');
    $vinculo=trim($_POST['vinculo']??'');
    $estado=trim($_POST['estado']??'Activo');
    $telefono=trim($_POST['telefono']??'');
    $email=trim($_POST['email']??'');
    if($email!==''&&!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error='El correo no es válido.';
        require __DIR__.'/../views/socios/form.php';
        return;
    }
    if($nombre===''||$vinculo==='') {
        $error='Nombre y vínculo son obligatorios.';
        require __DIR__.'/../views/socios/form.php';
        return;
    }
    Socio::actualizar($pdo, $id, $nombre, $vinculo, $estado, $telefono, $email);
    header('Location: index.php?accion=listarSocios');
    exit;
}
function eliminarSocio() {
    global $pdo;
    try {
        Socio::eliminar($pdo, $_GET['id']??0);
    }
    catch(PDOException $e) {
        listarSocios('No se puede eliminar un socio que tiene préstamos.');
        return;
    }
    header('Location: index.php?accion=listarSocios');
    exit;
}
