<?php require __DIR__ . '/../header.php'; ?>

<?php $editando = isset($usuario); ?>

<h1 class="h3 mb-3"><?= $editando ? 'Editar usuario' : 'Nuevo usuario' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars((string)$error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" action="index.php?accion=<?= $editando ? 'editarUsuario' : 'crearUsuario' ?>" class="col-md-6">
  <?php if ($editando): ?>
    <input type="hidden" name="id" value="<?= (int)$usuario->getId() ?>">
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">Número de usuario (ID)</label>
    <input class="form-control" value="<?= $editando ? (int)$usuario->getId() : 'Se genera automáticamente' ?>" readonly>
  </div>

  <div class="mb-3">
    <label class="form-label">Nombre</label>
    <input name="nombre" class="form-control" required
           value="<?= htmlspecialchars((string)($_POST['nombre'] ?? ($editando ? $usuario->getNombre() : '')), ENT_QUOTES, 'UTF-8') ?>">
  </div>

  <div class="mb-3">
    <label class="form-label">Correo</label>
    <input type="email" name="email" class="form-control" required
           value="<?= htmlspecialchars((string)($_POST['email'] ?? ($editando ? $usuario->getEmail() : '')), ENT_QUOTES, 'UTF-8') ?>">
  </div>

  <div class="mb-3">
    <label class="form-label">Contraseña <?= $editando ? '(dejar vacía para mantenerla)' : '' ?></label>
    <input type="password" name="contrasena" class="form-control" <?= $editando ? '' : 'required' ?> autocomplete="new-password">
  </div>

  <?php $rolActual = $_POST['rol_id'] ?? ($editando ? $usuario->getRol() : ''); ?>
  <div class="mb-3">
    <label class="form-label">Rol</label>
    <select name="rol_id" class="form-select" required>
      <option value="">Elegir rol</option>
      <?php foreach (($roles ?? []) as $rol): ?>
        <option value="<?= (int)$rol['id'] ?>"
          <?= (string)$rolActual === (string)$rol['id'] || (string)$rolActual === (string)$rol['nombre'] ? 'selected' : '' ?>>
          <?= htmlspecialchars((string)$rol['nombre'], ENT_QUOTES, 'UTF-8') ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="mb-3">
    <label class="form-label">Imagen de perfil</label>
    <input type="file" name="imagen_perfil" class="form-control" accept="image/png,image/jpeg,image/webp">
  </div>

  <button class="btn btn-primary">Guardar</button>
  <a href="index.php?accion=listarUsuarios" class="btn btn-link">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>
