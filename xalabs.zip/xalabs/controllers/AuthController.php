<?php
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../conexion.php';

function formLogin() {
    require __DIR__ . '/../login.php';
}

function login() {
    global $pdo;

    $email = trim($_POST['email'] ?? '');
    $contrasena = $_POST['contrasena'] ?? '';

    $usuario = Usuario::buscarPorEmail($pdo, $email);

    if ($usuario && password_verify($contrasena, $usuario->getContrasena())) {
        session_regenerate_id(true);
        $_SESSION['usuario_id'] = $usuario->getId();
        $_SESSION['usuario'] = $usuario->getNombre();
        $_SESSION['email'] = $usuario->getEmail();
        $_SESSION['rol'] = $usuario->getRol();
        $_SESSION['imagen_perfil'] = $usuario->getImagenPerfil();

        // Consulta vuelve al catálogo; administrador y bibliotecario van al panel.
        header('Location: ' . ($usuario->getRol() === 'consulta' ? 'catalogo.php' : 'index.php?accion=listar'));
        exit;
    }

    $mensaje_error = 'Correo o contraseña incorrectos.';
    require __DIR__ . '/../login.php';
}

function formRegistro() {
    require __DIR__ . '/../registro.php';
}

function registrarUsuario() {
    global $pdo;

    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contrasena = $_POST['contrasena'] ?? '';
    $confirmar = $_POST['confirmar'] ?? '';

    if ($nombre === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($contrasena) < 8 || $contrasena !== $confirmar) {
        $error = 'Completá los datos. La contraseña debe tener al menos 8 caracteres y coincidir.';
        require __DIR__ . '/../registro.php';
        return;
    }

    $consulta = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?');
    $consulta->execute([$email]);

    if ($consulta->fetch()) {
        $error = 'Ya existe una cuenta con ese correo.';
        require __DIR__ . '/../registro.php';
        return;
    }

    $consulta = $pdo->prepare("SELECT id FROM roles WHERE nombre = 'consulta'");
    $consulta->execute();
    $rol = $consulta->fetch(PDO::FETCH_ASSOC);

    if (!$rol) {
        $error = 'No está configurado el rol de consulta. Contactá al administrador.';
        require __DIR__ . '/../registro.php';
        return;
    }

    try {
        Usuario::crear($pdo, $email, $nombre, $contrasena, $rol['id'], 'default.png');
        $mensaje = 'Tu solicitud de registro fue enviada. Ya podés iniciar sesión.';
        require __DIR__ . '/../login.php';
    } catch (PDOException $e) {
        $error = 'No se pudo crear la cuenta. Revisá los datos e intentá nuevamente.';
        require __DIR__ . '/../registro.php';
    }
}

function logout() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: catalogo.php');
    exit;
}
