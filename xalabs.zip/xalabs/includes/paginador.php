<?php
// Paginador reutilizable. Conserva los filtros actuales al cambiar de página.
// Variables que espera de la vista: $pagina, $totalPaginas, $totalRegistros y, opcional, $porPagina.
if (isset($pagina, $totalPaginas, $totalRegistros) && (int)$totalRegistros > 0):
    $pagina = max(1, (int)$pagina);
    $totalPaginas = max(1, (int)$totalPaginas);
    $totalRegistros = (int)$totalRegistros;
    $tamanoPagina = max(1, (int)($porPagina ?? 20));
    $desde = ($pagina - 1) * $tamanoPagina + 1;
    $hasta = min($totalRegistros, $pagina * $tamanoPagina);

    $parametrosPagina = $_GET;
    unset($parametrosPagina['pagina']);
    $urlPagina = function ($numero) use ($parametrosPagina) {
        $parametros = $parametrosPagina;
        $parametros['pagina'] = $numero;
        return '?' . http_build_query($parametros);
    };

    $inicio = max(1, $pagina - 2);
    $fin = min($totalPaginas, $pagina + 2);
?>
<nav class="paginador" aria-label="Paginación">
  <p class="paginador-info">
    Mostrando <strong><?= $desde ?>–<?= $hasta ?></strong> de <strong><?= $totalRegistros ?></strong>
    <span class="paginador-pagina">· Página <?= $pagina ?> de <?= $totalPaginas ?></span>
  </p>

  <ul class="paginador-lista">
    <?php if ($pagina > 1): ?>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina(1)) ?>" aria-label="Primera página" title="Primera">«</a></li>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina($pagina - 1)) ?>" aria-label="Página anterior">‹<span class="pag-texto"> Anterior</span></a></li>
    <?php else: ?>
      <li class="pag-item deshabilitado"><span class="pag-link" aria-hidden="true">«</span></li>
      <li class="pag-item deshabilitado"><span class="pag-link" aria-hidden="true">‹<span class="pag-texto"> Anterior</span></span></li>
    <?php endif; ?>

    <?php if ($inicio > 1): ?>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina(1)) ?>">1</a></li>
      <?php if ($inicio > 2): ?><li class="pag-item pag-puntos"><span class="pag-link">…</span></li><?php endif; ?>
    <?php endif; ?>

    <?php for ($i = $inicio; $i <= $fin; $i++): ?>
      <?php if ($i === $pagina): ?>
        <li class="pag-item activo"><span class="pag-link" aria-current="page"><?= $i ?></span></li>
      <?php else: ?>
        <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina($i)) ?>" aria-label="Ir a la página <?= $i ?>"><?= $i ?></a></li>
      <?php endif; ?>
    <?php endfor; ?>

    <?php if ($fin < $totalPaginas): ?>
      <?php if ($fin < $totalPaginas - 1): ?><li class="pag-item pag-puntos"><span class="pag-link">…</span></li><?php endif; ?>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina($totalPaginas)) ?>"><?= $totalPaginas ?></a></li>
    <?php endif; ?>

    <?php if ($pagina < $totalPaginas): ?>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina($pagina + 1)) ?>" aria-label="Página siguiente"><span class="pag-texto">Siguiente </span>›</a></li>
      <li class="pag-item"><a class="pag-link" href="<?= htmlspecialchars($urlPagina($totalPaginas)) ?>" aria-label="Última página" title="Última">»</a></li>
    <?php else: ?>
      <li class="pag-item deshabilitado"><span class="pag-link" aria-hidden="true"><span class="pag-texto">Siguiente </span>›</span></li>
      <li class="pag-item deshabilitado"><span class="pag-link" aria-hidden="true">»</span></li>
    <?php endif; ?>
  </ul>
</nav>
<?php endif; ?>
