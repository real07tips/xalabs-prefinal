<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require __DIR__ . '/conexion.php';
require __DIR__ . '/models/Libro.php';

$filtros = ['titulo' => trim($_GET['titulo'] ?? ''), 'autor' => trim($_GET['autor'] ?? ''), 'genero' => trim($_GET['genero'] ?? '')];
$porPagina = 12;
$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$totalRegistros = Libro::contar($pdo, $filtros);
$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
$pagina = min($pagina, $totalPaginas);
$libros = Libro::listar($pdo, $filtros, $porPagina, ($pagina - 1) * $porPagina);

require __DIR__ . '/views/libros/catalogo.php';
