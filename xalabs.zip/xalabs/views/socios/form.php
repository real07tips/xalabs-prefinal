<?php require __DIR__ . '/../header.php'; ?>

<h1 class="h3 mb-3"><?= isset($socio) ? 'Editar socio' : 'Nuevo socio' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="index.php?accion=<?= isset($socio) ? 'editarSocio' : 'crearSocio' ?>" class="col-md-6">
  <?php if (isset($socio)): ?>
    <input type="hidden" name="id" value="<?= (int)$socio->getId() ?>">
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">Número de socio (ID)</label>
    <input class="form-control" value="<?= isset($socio) ? (int)$socio->getId() : 'Se genera automáticamente' ?>" readonly>
  </div>

  <div class="mb-3">
    <label class="form-label">Nombre</label>
    <input name="nombre" class="form-control" required
           value="<?= htmlspecialchars($_POST['nombre'] ?? (isset($socio) ? $socio->getNombre() : '')) ?>">
  </div>

  <div class="mb-3">
    <label class="form-label">Vínculo</label>
    <input name="vinculo" class="form-control" required
           value="<?= htmlspecialchars($_POST['vinculo'] ?? (isset($socio) ? $socio->getVinculo() : '')) ?>">
  </div>

  <?php $estadoActual = $_POST['estado'] ?? (isset($socio) ? $socio->getEstado() : 'Activo'); ?>
  <div class="mb-3">
    <label class="form-label">Estado</label>
    <select name="estado" class="form-select">
      <option <?= $estadoActual === 'Activo' ? 'selected' : '' ?>>Activo</option>
      <option <?= $estadoActual === 'Suspendido' ? 'selected' : '' ?>>Suspendido</option>
    </select>
  </div>

  <div class="mb-3">
    <label class="form-label">Teléfono</label>
    <input name="telefono" class="form-control"
           value="<?= htmlspecialchars($_POST['telefono'] ?? (isset($socio) ? $socio->getTelefono() : '')) ?>">
  </div>

  <div class="mb-3">
    <label class="form-label">Correo</label>
    <input type="email" name="email" class="form-control"
           value="<?= htmlspecialchars($_POST['email'] ?? (isset($socio) ? $socio->getEmail() : '')) ?>">
  </div>

  <button class="btn btn-primary">Guardar</button>
  <a href="index.php?accion=listarSocios" class="btn btn-link">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>
