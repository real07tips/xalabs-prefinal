<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3">Libros</h1>
    <a href="index.php?accion=formCrear" class="btn btn-primary">Nuevo libro</a>
</div>

<form method="GET" action="index.php" class="row g-2 mb-3">
    <input type="hidden" name="accion" value="listar">

    <div class="col-md-3">
        <input type="text" name="codigo" class="form-control"
               placeholder="Código" value="<?= htmlspecialchars($_GET['codigo'] ?? '') ?>">
    </div>
    <div class="col-md-3">
        <input type="text" name="titulo" class="form-control"
               placeholder="Título" value="<?= htmlspecialchars($_GET['titulo'] ?? '') ?>">
    </div>
    <div class="col-md-3">
        <input type="text" name="autor" class="form-control"
               placeholder="Autor" value="<?= htmlspecialchars($_GET['autor'] ?? '') ?>">
    </div>
    <div class="col-md-2">
        <input type="text" name="genero" class="form-control"
               placeholder="Género" value="<?= htmlspecialchars($_GET['genero'] ?? '') ?>">
    </div>
    <div class="col-md-1">
        <button type="submit" class="btn btn-primary w-100">Buscar</button>
    </div>
</form>

<?php if (empty($libros)): ?>
    <p class="text-muted">No se encontraron libros.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Portada</th>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Género</th>
                    <th>Descripción</th>
                    <th>Stock</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($libros as $libro): ?>
                    <tr>
                        <td><?= htmlspecialchars($libro->getCodigo()) ?></td>
                        <td>
                            <img src="img/portadas/<?= htmlspecialchars($libro->getImagen() ?: 'default.png') ?>"
                                 width="45" alt="Portada del libro">
                        </td>
                        <td><?= htmlspecialchars($libro->getTitulo()) ?></td>
                        <td><?= htmlspecialchars($libro->getAutor()) ?></td>
                        <td><?= htmlspecialchars($libro->getGenero()) ?></td>
                        <td><?= htmlspecialchars(mb_strimwidth($libro->getDescripcion() ?? '', 0, 60, '…')) ?></td>
                        <td>
                            <?php if ($libro->getStock() <= 0): ?>
                                <span class="badge text-bg-danger">0</span>
                            <?php else: ?>
                                <span class="badge text-bg-success"><?= $libro->getStock() ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="btn btn-sm btn-outline-secondary"
                               href="index.php?accion=formEditar&id=<?= (int) $libro->getId() ?>">✏️
                            </a>
                            <a class="btn btn-sm btn-outline-danger"
                               href="index.php?accion=eliminar&id=<?= (int) $libro->getId() ?>"
                               onclick="return confirm('¿Eliminar libro?')">🗑️
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../../includes/paginador.php'; ?>
<?php require __DIR__ . '/../footer.php'; ?>
