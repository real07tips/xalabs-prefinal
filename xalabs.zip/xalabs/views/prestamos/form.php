<?php
require __DIR__ . '/../header.php';

// Libros agrupados por género y ordenados por título, para el selector.
$gruposLibros = [];
foreach ($Libros as $l) {
    $genero = trim((string)$l->getGenero()) !== '' ? $l->getGenero() : 'Sin género';
    $gruposLibros[$genero][] = $l;
}
uksort($gruposLibros, function ($a, $b) {
    if ($a === 'Sin género') return 1;
    if ($b === 'Sin género') return -1;
    return strcasecmp($a, $b);
});
$libroElegidoId = (int)($_POST['libroId'] ?? (isset($prestamo) ? $prestamo->getLibroId() : 0));
$libroElegido = null;
foreach ($Libros as $l) { if ($l->getId() == $libroElegidoId) { $libroElegido = $l; break; } }
?>

<h1 class="h3 mb-3"><?= isset($prestamo) ? 'Editar prestamo' : 'Nuevo prestamo' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($prestamo) ? 'editarPrestamo' : 'crearPrestamo' ?>"
      class="col-md-6">

<?php if (isset($prestamo)): ?>
    <input type="hidden" name="id" value="<?= (int)$prestamo->getId() ?>">
<?php endif; ?>

        <div class="mb-3">
            <label class="form-label" id="pickerEtiqueta">Libro *</label>
            <div class="picker" id="libroPicker">
                <input type="hidden" name="libroId" id="libroId" value="<?= $libroElegido ? (int)$libroElegido->getId() : '' ?>">

                <button type="button" class="picker-boton" id="pickerBoton"
                        aria-haspopup="listbox" aria-expanded="false" aria-controls="pickerPanel" aria-labelledby="pickerEtiqueta pickerBoton">
                    <span class="picker-valor" id="pickerValor">
                        <?php if ($libroElegido): ?>
                            <img src="img/portadas/<?= htmlspecialchars($libroElegido->getImagen() ?: 'default.png') ?>" alt="">
                            <span class="picker-texto">
                                <strong><?= htmlspecialchars($libroElegido->getTitulo()) ?></strong>
                                <small><?= htmlspecialchars($libroElegido->getAutor()) ?></small>
                            </span>
                        <?php else: ?>
                            <span class="picker-placeholder">Seleccionar libro</span>
                        <?php endif; ?>
                    </span>
                    <span class="picker-flecha" aria-hidden="true">▾</span>
                </button>

                <div class="picker-panel" id="pickerPanel" hidden>
                    <div class="picker-busqueda">
                        <input type="search" id="pickerBuscar" class="form-control" autocomplete="off"
                               placeholder="Buscar por título, autor, género o código"
                               role="combobox" aria-expanded="true" aria-controls="pickerLista" aria-autocomplete="list">
                    </div>

                    <div class="picker-lista" id="pickerLista" role="listbox" aria-label="Libros">
                        <?php foreach ($gruposLibros as $genero => $librosGrupo): ?>
                            <div class="picker-grupo" role="group" aria-label="<?= htmlspecialchars($genero) ?>">
                                <div class="picker-grupo-titulo">
                                    <span><?= htmlspecialchars($genero) ?></span>
                                    <span class="picker-grupo-cant"><?= count($librosGrupo) ?></span>
                                </div>
                                <?php foreach ($librosGrupo as $libro): ?>
                                    <?php $sinStock = $libro->getStock() <= 0; ?>
                                    <div class="picker-opcion <?= $sinStock ? 'sin-stock' : '' ?> <?= $libroElegido && $libroElegido->getId() == $libro->getId() ? 'seleccionada' : '' ?>"
                                         role="option" id="opcion-libro-<?= (int)$libro->getId() ?>"
                                         aria-selected="<?= $libroElegido && $libroElegido->getId() == $libro->getId() ? 'true' : 'false' ?>"
                                         data-id="<?= (int)$libro->getId() ?>"
                                         data-titulo="<?= htmlspecialchars($libro->getTitulo()) ?>"
                                         data-autor="<?= htmlspecialchars($libro->getAutor()) ?>"
                                         data-genero="<?= htmlspecialchars($genero) ?>"
                                         data-codigo="<?= htmlspecialchars($libro->getCodigo()) ?>"
                                         data-imagen="img/portadas/<?= htmlspecialchars($libro->getImagen() ?: 'default.png') ?>">
                                        <img src="img/portadas/<?= htmlspecialchars($libro->getImagen() ?: 'default.png') ?>" alt="" loading="lazy">
                                        <span class="picker-texto">
                                            <strong><?= htmlspecialchars($libro->getTitulo()) ?></strong>
                                            <small><?= htmlspecialchars($libro->getAutor()) ?> · <?= htmlspecialchars($libro->getCodigo()) ?></small>
                                        </span>
                                        <span class="badge <?= $sinStock ? 'text-bg-danger' : 'text-bg-success' ?>">
                                            <?= $sinStock ? 'Sin stock' : 'Stock ' . $libro->getStock() ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                        <p class="picker-vacio" id="pickerVacio" hidden>No hay libros que coincidan con la búsqueda.</p>
                    </div>
                </div>
                <div class="picker-error" id="pickerError" hidden>Seleccioná un libro para continuar.</div>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Socio *</label>
            <select name="socioId" class="form-select" required>
                <option value="">Seleccionar socio</option>
                <?php foreach ($Socios as $socio): ?>
                    <option value="<?= $socio->getId(); ?>" <?= isset($prestamo) && $prestamo->getSocioId() == $socio->getId() ? 'selected' : '' ?>><?= (int)$socio->getId(); ?> - <?= htmlspecialchars($socio->getNombre()); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de Prestamo *</label>
            <input type="date" name="fechaPrestamo" class="form-control" value="<?= htmlspecialchars($_POST['fechaPrestamo'] ?? ((isset($prestamo) ? $prestamo->getFechaPrestamo() : date('Y-m-d')))) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Plazo de devolución</label>
            <select id="plazo" class="form-select">
                <option value="2">48 horas (2 días)</option>
                <option value="7" <?= isset($prestamo) ? '' : 'selected' ?>>7 días</option>
                <option value="" <?= isset($prestamo) ? 'selected' : '' ?>>Otra fecha</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de devolución *</label>
            <input type="date" name="fechaDevolucion" id="fechaDevolucion" class="form-control" required
                   value="<?= htmlspecialchars($_POST['fechaDevolucion'] ?? ((isset($prestamo) ? $prestamo->getFechaDevolucion() : date('Y-m-d', strtotime('+7 days'))))) ?>"> 
                </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary"><?= isset($prestamo) ? 'Guardar cambios' : 'Crear préstamo' ?></button>
            <a href="index.php?accion=listarPrestamos" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>

<script>
// Calcula la fecha de devolución a partir de la fecha de préstamo y el plazo elegido.
const plazo = document.getElementById('plazo');
const fechaPrestamo = document.querySelector('[name="fechaPrestamo"]');
const fechaDevolucion = document.getElementById('fechaDevolucion');

function aplicarPlazo() {
    if (plazo.value === '' || !fechaPrestamo.value) return;
    const [a, m, d] = fechaPrestamo.value.split('-').map(Number);
    const f = new Date(a, m - 1, d + Number(plazo.value));
    fechaDevolucion.value = f.getFullYear() + '-' + String(f.getMonth() + 1).padStart(2, '0') + '-' + String(f.getDate()).padStart(2, '0');
}

plazo.addEventListener('change', aplicarPlazo);
fechaPrestamo.addEventListener('change', aplicarPlazo);
fechaDevolucion.addEventListener('input', () => { plazo.value = ''; });
</script>

<script>
// Selector de libros: buscador + lista agrupada por género.
(function () {
    const picker = document.getElementById('libroPicker');
    const boton = document.getElementById('pickerBoton');
    const panel = document.getElementById('pickerPanel');
    const buscar = document.getElementById('pickerBuscar');
    const lista = document.getElementById('pickerLista');
    const vacio = document.getElementById('pickerVacio');
    const valor = document.getElementById('pickerValor');
    const campo = document.getElementById('libroId');
    const error = document.getElementById('pickerError');
    const opciones = Array.from(lista.querySelectorAll('.picker-opcion'));
    const grupos = Array.from(lista.querySelectorAll('.picker-grupo'));
    let activa = null;

    const normalizar = t => (t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    opciones.forEach(o => {
        o._texto = normalizar([o.dataset.titulo, o.dataset.autor, o.dataset.genero, o.dataset.codigo].join(' '));
    });

    const visibles = () => opciones.filter(o => !o.hidden);

    function marcarActiva(op, scroll) {
        if (activa) activa.classList.remove('activa');
        activa = op || null;
        if (activa) {
            activa.classList.add('activa');
            buscar.setAttribute('aria-activedescendant', activa.id);
            if (scroll) activa.scrollIntoView({ block: 'nearest' });
        } else {
            buscar.removeAttribute('aria-activedescendant');
        }
    }

    function filtrar() {
        const palabras = normalizar(buscar.value).split(/\s+/).filter(Boolean);
        opciones.forEach(o => { o.hidden = !palabras.every(p => o._texto.includes(p)); });
        grupos.forEach(g => {
            const n = g.querySelectorAll('.picker-opcion:not([hidden])').length;
            g.hidden = n === 0;
            g.querySelector('.picker-grupo-cant').textContent = n;
        });
        const v = visibles();
        vacio.hidden = v.length > 0;
        marcarActiva(v[0] || null, false);
    }

    function abrir() {
        panel.hidden = false;
        boton.setAttribute('aria-expanded', 'true');
        picker.classList.add('abierto');
        buscar.value = '';
        filtrar();
        const elegida = lista.querySelector('.picker-opcion.seleccionada');
        if (elegida) { marcarActiva(elegida, true); }
        buscar.focus();
    }

    function cerrar(devolverFoco) {
        panel.hidden = true;
        boton.setAttribute('aria-expanded', 'false');
        picker.classList.remove('abierto');
        if (devolverFoco) boton.focus();
    }

    function elegir(op) {
        opciones.forEach(o => { o.classList.remove('seleccionada'); o.setAttribute('aria-selected', 'false'); });
        op.classList.add('seleccionada');
        op.setAttribute('aria-selected', 'true');
        campo.value = op.dataset.id;
        valor.innerHTML = '';
        const img = document.createElement('img');
        img.src = op.dataset.imagen; img.alt = '';
        const txt = document.createElement('span'); txt.className = 'picker-texto';
        const t = document.createElement('strong'); t.textContent = op.dataset.titulo;
        const a = document.createElement('small'); a.textContent = op.dataset.autor;
        txt.append(t, a);
        valor.append(img, txt);
        boton.classList.remove('invalido');
        error.hidden = true;
        cerrar(true);
    }

    boton.addEventListener('click', () => panel.hidden ? abrir() : cerrar(false));
    buscar.addEventListener('input', filtrar);

    lista.addEventListener('click', e => {
        const op = e.target.closest('.picker-opcion');
        if (op) elegir(op);
    });
    lista.addEventListener('mousemove', e => {
        const op = e.target.closest('.picker-opcion');
        if (op && op !== activa) marcarActiva(op, false);
    });

    panel.addEventListener('keydown', e => {
        const v = visibles();
        const i = v.indexOf(activa);
        if (e.key === 'ArrowDown') { e.preventDefault(); marcarActiva(v[Math.min(i + 1, v.length - 1)], true); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); marcarActiva(v[Math.max(i - 1, 0)], true); }
        else if (e.key === 'Enter') { e.preventDefault(); if (activa) elegir(activa); }
        else if (e.key === 'Escape') { e.preventDefault(); cerrar(true); }
        else if (e.key === 'Tab') { cerrar(false); }
    });

    document.addEventListener('click', e => { if (!picker.contains(e.target)) cerrar(false); });

    // El campo es oculto, así que se valida a mano antes de enviar.
    picker.closest('form').addEventListener('submit', e => {
        if (!campo.value) {
            e.preventDefault();
            boton.classList.add('invalido');
            error.hidden = false;
            boton.focus();
        }
    });
})();
</script>
<?php require __DIR__ . '/../footer.php'; ?>