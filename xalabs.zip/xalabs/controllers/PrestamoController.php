<?php
require_once __DIR__ . '/../models/Prestamo.php';
require_once __DIR__ . '/../models/Socio.php';
require_once __DIR__ . '/../models/Libro.php';
require_once __DIR__ . '/../conexion.php';

function listarPrestamos() {
    global $pdo;
    $porPagina = 10;
    $pagina = max(1, (int)($_GET['pagina'] ?? 1));
    $totalRegistros = Prestamo::contar($pdo);
    $totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
    $pagina = min($pagina, $totalPaginas);
    $prestamos = Prestamo::listar($pdo, $porPagina, ($pagina - 1) * $porPagina);
    require __DIR__ . '/../views/prestamos/listar.php';
}

function formCrearPrestamo() {
    global $pdo;

    $Socios=Socio::listar($pdo);
    $Libros=Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function crearPrestamo() {
    global $pdo;

    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? date('Y-m-d'));
    $fechaDevolucion = trim($_POST['fechaDevolucion'] ?? date('Y-m-d', strtotime('+7 days', strtotime($fechaPrestamo))));

    if ($socioId === '' || $libroId === '' || $fechaPrestamo === '' || $fechaDevolucion === '') {
        $error = 'Todos los campos son obligatorios.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    if (strtotime($fechaPrestamo) === false || strtotime($fechaDevolucion) === false || $fechaDevolucion < $fechaPrestamo) {
        $error = 'La fecha de devolución debe ser igual o posterior a la fecha del préstamo.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el socio exista antes de crear el préstamo
    $stmt = $pdo->prepare('SELECT id FROM socios WHERE id = ?');
    $stmt->execute([(int)$socioId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El socio seleccionado no existe.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el libro exista antes de crear el préstamo
    $stmt = $pdo->prepare('SELECT id FROM libros WHERE id = ?');
    $stmt->execute([(int)$libroId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El libro seleccionado no existe.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    try {
        Prestamo::crear($pdo, (int)$socioId, (int)$libroId, $fechaPrestamo, $fechaDevolucion);
    } catch (InvalidArgumentException $e) {
        $error = $e->getMessage();
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    } catch (PDOException $e) {
        $error = 'No se pudo crear el préstamo porque la clave foránea de la base de datos no coincide con el socio o libro seleccionado.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}


function formEditarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    $prestamo = Prestamo::buscar($pdo, $id);

    if (!$prestamo) {
        header('Location: index.php?accion=listarPrestamos');
        exit;
    }

    $Socios = Socio::listar($pdo);
    $Libros = Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function editarPrestamo() {
    global $pdo;

    $id = (int)($_POST['id'] ?? 0);
    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? date('Y-m-d'));
    $fechaDevolucion = trim($_POST['fechaDevolucion'] ?? date('Y-m-d', strtotime('+7 days', strtotime($fechaPrestamo))));

    if ($id <= 0 || $socioId === '' || $libroId === '' || $fechaPrestamo === '' || $fechaDevolucion === '') {
        $error = 'Todos los campos son obligatorios.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    if (strtotime($fechaPrestamo) === false || strtotime($fechaDevolucion) === false || $fechaDevolucion < $fechaPrestamo) {
        $error = 'La fecha de devolución debe ser igual o posterior a la fecha del préstamo.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el socio exista antes de editar el préstamo
    $stmt = $pdo->prepare('SELECT id FROM socios WHERE id = ?');
    $stmt->execute([(int)$socioId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El socio seleccionado no existe.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el libro exista antes de editar el préstamo
    $stmt = $pdo->prepare('SELECT id FROM libros WHERE id = ?');
    $stmt->execute([(int)$libroId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El libro seleccionado no existe.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    try {
        Prestamo::editar($pdo, $id, (int)$socioId, (int)$libroId, $fechaPrestamo, $fechaDevolucion);
    } catch (PDOException $e) {
        $error = 'No se pudo editar el préstamo porque la clave foránea de la base de datos no coincide con el socio o libro seleccionado.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}

function eliminarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        Prestamo::eliminar($pdo, $id);
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}
