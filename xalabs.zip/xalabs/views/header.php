<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($tituloPagina ?? 'Biblioteca — Xa Labs') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark mb-4">
  <div class="container gap-2">
    <a class="navbar-brand" href="index.php">📚 Biblioteca UTU</a>

    <?php $rolActual = $_SESSION['rol'] ?? 'consulta'; ?>
    <div class="navbar-links">
      <?php if ($rolActual === 'administrador'): ?>
        <a href="index.php?accion=listarUsuarios" class="btn btn-light btn-sm">Usuarios</a>
      <?php endif; ?>
      <?php if (in_array($rolActual, ['administrador', 'bibliotecario'], true)): ?>
        <a href="index.php?accion=listar" class="btn btn-light btn-sm">Libros</a>
        <a href="index.php?accion=listarSocios" class="btn btn-light btn-sm">Socios</a>
        <a href="index.php?accion=listarPrestamos" class="btn btn-light btn-sm">Préstamos</a>
      <?php endif; ?>
      <a href="catalogo.php" class="btn btn-light btn-sm">Catálogo</a>
    </div>

    <?php if (isset($_SESSION['usuario'])): ?>
      <div class="usuario-sesion">
        <div class="usuario-avatar">
          <?php if (!empty($_SESSION['imagen_perfil']) && $_SESSION['imagen_perfil'] !== 'default.png'): ?>
            <img src="uploads/<?= htmlspecialchars($_SESSION['imagen_perfil']) ?>" alt="Foto de perfil">
          <?php else: ?>
            <?= strtoupper(substr($_SESSION['usuario'], 0, 1)) ?>
          <?php endif; ?>
        </div>
        <div class="usuario-datos">
          <span class="usuario-nombre"><?= htmlspecialchars($_SESSION['usuario']) ?></span>
          <span class="usuario-rol"><?= htmlspecialchars(ucfirst($_SESSION['rol'] ?? 'consulta')) ?></span>
        </div>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Salir</a>
      </div>
    <?php else: ?>
      <a href="index.php?accion=login" class="btn btn-primary btn-sm">Iniciar sesión</a>
    <?php endif; ?>
  </div>
</nav>
<div class="container pb-5">
