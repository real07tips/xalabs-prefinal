<?php
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../conexion.php';
function listarUsuarios() {
    global $pdo;
    $porPagina = 10;
    $pagina = max(1, (int)($_GET['pagina'] ?? 1));
    $totalRegistros = Usuario::contar($pdo);
    $totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
    $pagina = min($pagina, $totalPaginas);
    $usuarios=Usuario::listar($pdo, $porPagina, ($pagina - 1) * $porPagina);
    require __DIR__.'/../views/usuarios/listar.php';
}

function formCrearUsuario() {
    global $pdo;
    $roles=$pdo->query('SELECT * FROM roles ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
    require __DIR__.'/../views/usuarios/form.php';
}

function crearUsuario() {
    global $pdo;
    $email=trim($_POST['email']??'');
    $nombre=trim($_POST['nombre']??'');
    $clave=$_POST['contrasena']??'';
    $rolId=(int)($_POST['rol_id']??0);
    $roles=$pdo->query('SELECT * FROM roles ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
    $imagen=guardarPerfil();
    
    if($email===''||$nombre===''||$clave===''||$rolId<1||$imagen===false) {
        $error='Completá los datos y elegí una imagen válida.';
        require __DIR__.'/../views/usuarios/form.php';
        return;
    }

    try {
        Usuario::crear($pdo, $email, $nombre, $clave, $rolId, $imagen??'default.png');
    }

    catch(PDOException $e) {
        $error='No se pudo guardar. Revisá que el correo no esté repetido.';
        require __DIR__.'/../views/usuarios/form.php';
        return;
    }
    header('Location: index.php?accion=listarUsuarios');
    exit;
}
function formEditarUsuario() {
    global $pdo;
    $usuario=Usuario::buscarPorId($pdo, $_GET['id']??0);
    if(!$usuario) {
        header('Location: index.php?accion=listarUsuarios');
        exit;
    }
    $roles=$pdo->query('SELECT * FROM roles ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
    require __DIR__.'/../views/usuarios/form.php';
}
function editarUsuario() {
    global $pdo;
    $id=(int)($_POST['id']??0);
    $usuario=Usuario::buscarPorId($pdo, $id);
    if(!$usuario) {
        header('Location: index.php?accion=listarUsuarios');
        exit;
    }
    $email=trim($_POST['email']??'');
    $nombre=trim($_POST['nombre']??'');
    $clave=$_POST['contrasena']??'';
    $rolId=(int)($_POST['rol_id']??0);
    $roles=$pdo->query('SELECT * FROM roles ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
    $nueva=guardarPerfil();
    if($email===''||$nombre===''||$rolId<1||$nueva===false) {
        $error='Revisá los datos ingresados.';
        require __DIR__.'/../views/usuarios/form.php';
        return;
    }
    try {
        Usuario::actualizar($pdo, $id, $email, $nombre, $clave, $rolId, $nueva??$usuario->getImagenPerfil());
    }
    catch(PDOException $e) {
        $error='No se pudo actualizar el usuario.';
        require __DIR__.'/../views/usuarios/form.php';
        return;
    }
    // Si se edita al usuario con sesión iniciada, se refresca lo que se muestra arriba (foto, nombre, rol).
    if (($_SESSION['usuario_id'] ?? 0) == $id) {
        $actualizado = Usuario::buscarPorId($pdo, $id);
        if ($actualizado) {
            $_SESSION['usuario'] = $actualizado->getNombre();
            $_SESSION['email'] = $actualizado->getEmail();
            $_SESSION['rol'] = $actualizado->getRol();
            $_SESSION['imagen_perfil'] = $actualizado->getImagenPerfil();
        }
    }
    header('Location: index.php?accion=listarUsuarios');
    exit;
}
function eliminarUsuario() {
    global $pdo;
    Usuario::eliminar($pdo, $_GET['id']??0);
    header('Location: index.php?accion=listarUsuarios');
    exit;
}
function guardarPerfil() {
    if(!isset($_FILES['imagen_perfil'])||$_FILES['imagen_perfil']['error']===UPLOAD_ERR_NO_FILE)return null;
    if($_FILES['imagen_perfil']['error']!==UPLOAD_ERR_OK||$_FILES['imagen_perfil']['size']>2*1024*1024||@getimagesize($_FILES['imagen_perfil']['tmp_name'])===false)return false;
    $ext=strtolower(pathinfo($_FILES['imagen_perfil']['name'], PATHINFO_EXTENSION));
    if(!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true))return false;
    $nombre=uniqid('perfil_', true).'.'.$ext;
    return move_uploaded_file($_FILES['imagen_perfil']['tmp_name'], __DIR__.'/../uploads/'.$nombre)?$nombre:false;
}
