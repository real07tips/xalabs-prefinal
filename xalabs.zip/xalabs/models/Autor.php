<?php
class Autor {
    private $id, $nombre;
    public function __construct($id, $nombre) {
        $this->id=$id;
        $this->nombre=$nombre;
    }
    public function getId() {
        return $this->id;
    }
    public function getNombre() {
        return $this->nombre;
    }
    public static function listar($pdo) {
        $filas=$pdo->query('SELECT * FROM autores ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
        $lista=[];
        foreach($filas as $f)$lista[]=new Autor($f['id'], $f['nombre']);
        return $lista;
    }
    // Si el autor ya existe devuelve su id; si no, lo crea.
    public static function buscarOCrear($pdo, $nombre) {
        $s=$pdo->prepare('SELECT id FROM autores WHERE nombre=?');
        $s->execute([$nombre]);
        $id=$s->fetchColumn();
        if($id)return (int)$id;
        $s=$pdo->prepare('INSERT INTO autores(nombre) VALUES(?)');
        $s->execute([$nombre]);
        return (int)$pdo->lastInsertId();
    }
}
