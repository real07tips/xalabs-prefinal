</div>
<footer class="site-footer">
  <span>© <?= date('Y') ?> XA Labs</span>
  <span>Sistema de Biblioteca</span>
</footer>
</body>
</html>
