<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Socios</h1>
  <a href="index.php?accion=formCrearSocio" class="btn btn-primary">+ Nuevo socio</a>
</div>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="GET" action="index.php" class="filtros filtros-4">
  <input type="hidden" name="accion" value="listarSocios">
  <div>
    <label class="form-label" for="f-nombre">Nombre</label>
    <input type="text" id="f-nombre" name="nombre" class="form-control" placeholder="Ej.: Ana"
           value="<?= htmlspecialchars($filtros['nombre'] ?? '') ?>">
  </div>
  <div>
    <label class="form-label" for="f-email">Correo</label>
    <input type="text" id="f-email" name="email" class="form-control" placeholder="Ej.: ana@mail.com"
           value="<?= htmlspecialchars($filtros['email'] ?? '') ?>">
  </div>
  <div>
    <label class="form-label" for="f-telefono">Teléfono</label>
    <input type="text" id="f-telefono" name="telefono" class="form-control" placeholder="Ej.: 099123456"
           value="<?= htmlspecialchars($filtros['telefono'] ?? '') ?>">
  </div>
  <div>
    <label class="form-label" for="f-vinculo">Vínculo</label>
    <input type="text" id="f-vinculo" name="vinculo" class="form-control" placeholder="Ej.: Estudiante" list="lista-vinculos"
           value="<?= htmlspecialchars($filtros['vinculo'] ?? '') ?>">
    <datalist id="lista-vinculos">
      <?php foreach ($vinculos ?? [] as $v): ?>
        <option value="<?= htmlspecialchars($v) ?>"></option>
      <?php endforeach; ?>
    </datalist>
  </div>
  <div class="filtros-acciones">
    <button type="submit" class="btn btn-primary">Buscar</button>
    <a href="index.php?accion=listarSocios" class="btn btn-outline-secondary">Limpiar</a>
  </div>
</form>

<?php if (empty($socios)): ?>
  <p class="text-muted">
    <?= !empty($hayFiltros) ? 'No encontramos socios con esos filtros.' : 'Todavía no hay socios cargados.' ?>
  </p>
<?php else: ?>
  <table class="table align-middle">
    <thead>
      <tr>
        <th>Nro. socio</th>
        <th>Nombre</th>
        <th>Teléfono</th>
        <th>Correo</th>
        <th>Vínculo</th>
        <th>Estado</th>
        <th class="text-end">Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($socios as $socio): ?>
      <tr>
        <td><?= htmlspecialchars($socio->getNroSocio()) ?></td>
        <td><?= htmlspecialchars($socio->getNombre()) ?></td>
        <td><?= htmlspecialchars($socio->getTelefono() ?? "") ?></td>
        <td><?= htmlspecialchars($socio->getEmail() ?? "") ?></td>
        <td><?= htmlspecialchars($socio->getVinculo()) ?></td>
        <td>
          <?php if ($socio->getEstado() === 'Activo'): ?>
            <span class="badge text-bg-success">Activo</span>
          <?php else: ?>
            <span class="badge text-bg-danger">Suspendido</span>
          <?php endif; ?>
        </td>
        <td class="text-end">
          <a href="index.php?accion=formEditarSocio&id=<?= (int)$socio->getId() ?>" class="btn btn-sm btn-outline-secondary">✏️</a>
          <a href="index.php?accion=eliminarSocio&id=<?= (int)$socio->getId() ?>"
             class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este socio?');">🗑️</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/../../includes/paginador.php'; ?>
<?php require __DIR__ . '/../footer.php'; ?>
