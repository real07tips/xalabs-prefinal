<?php
class Usuario  {
    private $id, $email, $nombre, $contrasena, $rol, $imagenPerfil;
    public function __construct($email, $nombre, $contrasena, $rol, $imagenPerfil, $id=null) {
        $this->id=$id;
        $this->email=$email;
        $this->nombre=$nombre;
        $this->contrasena=$contrasena;
        $this->rol=$rol;
        $this->imagenPerfil=$imagenPerfil;
    }
    public function getId() {
        return $this->id;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getNombre() {
        return $this->nombre;
    }
    public function getContrasena() {
        return $this->contrasena;
    }
    public function getRol() {
        return $this->rol;
    }
    public function getImagenPerfil() {
        return $this->imagenPerfil;
    }
    public static function buscarPorEmail($pdo, $email) {
        $s = $pdo->prepare('SELECT u.*, r.nombre AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.email = ?');
        $s->execute([$email]);
        $u = $s->fetch(PDO::FETCH_ASSOC);

        if (!$u) {
            return null;
        }

        return new Usuario($u['email'], $u['nombre'], $u['contrasena'], $u['rol'], $u['imagen_perfil'], $u['id']);
    }

    public static function listar($pdo, $limite = null, $offset = 0) {
        $sql='SELECT u.*,r.nombre AS rol FROM usuarios u JOIN roles r ON r.id=u.rol_id ORDER BY u.nombre';
        if ($limite !== null) $sql .= ' LIMIT ' . max(1, (int)$limite) . ' OFFSET ' . max(0, (int)$offset);
        $f=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $lista=[];
        foreach($f as $u)$lista[]=new Usuario($u['email'], $u['nombre'], $u['contrasena'], $u['rol'], $u['imagen_perfil'], $u['id']);
        return $lista;
    }
    public static function contar($pdo) {
        return (int)$pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn();
    }
    public static function buscarPorId($pdo, $id) {
        $s=$pdo->prepare('SELECT u.*,r.nombre AS rol FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.id=?');
        $s->execute([(int)$id]);
        $u=$s->fetch(PDO::FETCH_ASSOC);
        return $u?new Usuario($u['email'], $u['nombre'], $u['contrasena'], $u['rol'], $u['imagen_perfil'], $u['id']):null;
    }
    public static function crear($pdo, $email, $nombre, $contrasena, $rolId, $imagen) {
        $s=$pdo->prepare('INSERT INTO usuarios(email,nombre,contrasena,rol_id,imagen_perfil) VALUES(?,?,?,?,?)');
        return $s->execute([$email, $nombre, password_hash($contrasena, PASSWORD_DEFAULT), $rolId, $imagen]);
    }
    public static function actualizar($pdo, $id, $email, $nombre, $contrasena, $rolId, $imagen) {
        if($contrasena!=='') {
            $s=$pdo->prepare('UPDATE usuarios SET email=?,nombre=?,contrasena=?,rol_id=?,imagen_perfil=? WHERE id=?');
            return $s->execute([$email, $nombre, password_hash($contrasena, PASSWORD_DEFAULT), $rolId, $imagen, $id]);
        }
        $s=$pdo->prepare('UPDATE usuarios SET email=?,nombre=?,rol_id=?,imagen_perfil=? WHERE id=?');
        return $s->execute([$email, $nombre, $rolId, $imagen, $id]);
    }
    public static function eliminar($pdo, $id) {
        $s=$pdo->prepare('DELETE FROM usuarios WHERE id=?');
        return $s->execute([(int)$id]);
    }
}
