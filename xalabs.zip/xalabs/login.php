<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['usuario_id'])) {
    header('Location: ' . (($_SESSION['rol'] ?? 'consulta') === 'consulta' ? 'catalogo.php' : 'index.php?accion=listar'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión - Biblioteca UTU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body class="login-page">
<div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    <div class="card login-card p-4 p-md-5" style="max-width: 420px; width: 100%;">
        <div class="text-center mb-3">
            <img src="img/logobg.png" alt="Logo" style="max-width: 250px; height: auto;">
        </div>

        <?php if (!empty($mensaje_error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($mensaje_error) ?></div>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (!empty($mensaje)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <form method="POST" action="index.php?accion=autenticar">
            <div class="mb-3">
                <label class="form-label">Correo electrónico</label>
                <input type="email" name="email" class="form-control" required autocomplete="username">
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" name="contrasena" class="form-control" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-xa w-100">Ingresar</button>
        </form>
        <div class="login-links text-center mt-3">
            <p class="mb-2">¿No tenés cuenta? <a href="index.php?accion=registro">Solicitar registro</a></p>
            <p class="mb-0"><a href="catalogo.php">← Volver al catálogo</a></p>
        </div>
    </div>
</div>
</body>
</html>
