<?php
class Libro {
    private $id, $codigo, $titulo, $autorId, $autor, $genero, $stock, $imagen, $descripcion;

    public function __construct($id, $codigo, $titulo, $autorId, $autor, $genero, $stock, $imagen, $descripcion) {
        $this->id = $id;
        $this->codigo = $codigo;
        $this->titulo = $titulo;
        $this->autorId = $autorId;
        $this->autor = $autor;
        $this->genero = $genero;
        $this->stock = $stock;
        $this->imagen = $imagen;
        $this->descripcion = $descripcion;
    }

    public function getId() { return $this->id; }
    public function getCodigo() { return $this->codigo; }
    public function getTitulo() { return $this->titulo; }
    public function getAutorId() { return $this->autorId; }
    public function getAutor() { return $this->autor; }
    public function getGenero() { return $this->genero; }
    public function getStock() { return (int)$this->stock; }
    public function getImagen() { return $this->imagen; }
    public function getDescripcion() { return $this->descripcion; }

    private static function desdeFila($f) {
        return new Libro($f['id'], $f['codigo'], $f['titulo'], $f['autor_id'], $f['autor'], $f['genero'], $f['stock'], $f['imagen'], $f['descripcion']);
    }

    public static function listar($pdo, $filtros = [], $limite = null, $offset = 0) {
        $sql = 'SELECT l.*, a.nombre AS autor FROM libros l JOIN autores a ON a.id = l.autor_id WHERE 1=1';
        $datos = [];
        foreach (['titulo' => 'l.titulo', 'autor' => 'a.nombre', 'genero' => 'l.genero', 'codigo' => 'l.codigo'] as $campo => $columna) {
            if (!empty($filtros[$campo])) {
                $sql .= " AND $columna LIKE ?";
                $datos[] = '%' . $filtros[$campo] . '%';
            }
        }
        $sql .= ' ORDER BY l.titulo';
        if ($limite !== null) {
            $sql .= ' LIMIT ' . max(1, (int)$limite) . ' OFFSET ' . max(0, (int)$offset);
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($datos);
        $libros = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $f) $libros[] = self::desdeFila($f);
        return $libros;
    }

    public static function contar($pdo, $filtros = []) {
        $sql = 'SELECT COUNT(*) FROM libros l JOIN autores a ON a.id = l.autor_id WHERE 1=1';
        $datos = [];
        foreach (['titulo' => 'l.titulo', 'autor' => 'a.nombre', 'genero' => 'l.genero', 'codigo' => 'l.codigo'] as $campo => $columna) {
            if (!empty($filtros[$campo])) {
                $sql .= " AND $columna LIKE ?";
                $datos[] = '%' . $filtros[$campo] . '%';
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($datos);
        return (int)$stmt->fetchColumn();
    }

    public static function buscarPorId($pdo, $id) {
        $stmt = $pdo->prepare('SELECT l.*, a.nombre AS autor FROM libros l JOIN autores a ON a.id=l.autor_id WHERE l.id=?');
        $stmt->execute([(int)$id]);
        $f = $stmt->fetch(PDO::FETCH_ASSOC);
        return $f ? self::desdeFila($f) : null;
    }

    public static function buscarPorCodigo($pdo, $codigo) {
        $stmt = $pdo->prepare('SELECT l.*, a.nombre AS autor FROM libros l JOIN autores a ON a.id=l.autor_id WHERE l.codigo=?');
        $stmt->execute([$codigo]);
        $f = $stmt->fetch(PDO::FETCH_ASSOC);
        return $f ? self::desdeFila($f) : null;
    }

    public static function crear($pdo, $codigo, $titulo, $autorId, $genero, $stock, $imagen, $descripcion) {
        $stmt = $pdo->prepare('INSERT INTO libros (codigo,titulo,autor_id,genero,stock,imagen,descripcion) VALUES (?,?,?,?,?,?,?)');
        return $stmt->execute([$codigo,$titulo,$autorId,$genero,$stock,$imagen,$descripcion]);
    }

    public static function actualizar($pdo, $id, $codigo, $titulo, $autorId, $genero, $stock, $imagen, $descripcion) {
        $stmt = $pdo->prepare('UPDATE libros SET codigo=?, titulo=?, autor_id=?, genero=?, stock=?, imagen=?, descripcion=? WHERE id=?');
        return $stmt->execute([$codigo,$titulo,$autorId,$genero,$stock,$imagen,$descripcion,$id]);
    }

    public static function eliminar($pdo, $id) {
        $stmt = $pdo->prepare('DELETE FROM libros WHERE id=?');
        return $stmt->execute([(int)$id]);
    }
}
