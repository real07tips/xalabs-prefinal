<?php
$tituloPagina = 'Catálogo — Biblioteca UTU';
require __DIR__ . '/../header.php';

$total = $totalRegistros ?? count($libros);
$disponibles = count(array_filter($libros, function ($l) { return $l->getStock() > 0; }));
?>

<section class="cat-hero">
    <img src="img/logo-xaread-transparente.png" class="cat-logo" alt="XA Read">
    <div>
        <h1>Catálogo de libros</h1>
        <p>Consultá qué libros hay en la biblioteca y cuáles están disponibles para retirar.</p>
        <div class="cat-resumen">
            <span><?= $total ?> <?= $total === 1 ? 'libro' : 'libros' ?></span>
            <span class="cat-ok"><?= $disponibles ?> <?= $disponibles === 1 ? 'disponible' : 'disponibles' ?> en esta página</span>
        </div>
    </div>
</section>

<form method="GET" action="catalogo.php" class="cat-filtros">
    <div>
        <label class="form-label" for="f-titulo">Título</label>
        <input type="text" id="f-titulo" name="titulo" class="form-control"
               placeholder="Ej.: 1984" value="<?= htmlspecialchars($_GET['titulo'] ?? '') ?>">
    </div>
    <div>
        <label class="form-label" for="f-autor">Autor</label>
        <input type="text" id="f-autor" name="autor" class="form-control"
               placeholder="Ej.: George Orwell" value="<?= htmlspecialchars($_GET['autor'] ?? '') ?>">
    </div>
    <div>
        <label class="form-label" for="f-genero">Género</label>
        <input type="text" id="f-genero" name="genero" class="form-control"
               placeholder="Ej.: Fantasía" value="<?= htmlspecialchars($_GET['genero'] ?? '') ?>">
    </div>
    <div class="cat-acciones">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <a href="catalogo.php" class="btn btn-outline-secondary">Limpiar</a>
    </div>
</form>

<?php if (empty($libros)): ?>
    <p class="text-muted">No encontramos libros con esos filtros. Probá con otras palabras o <a href="catalogo.php">mirá todo el catálogo</a>.</p>
<?php else: ?>
    <div class="catalogo-grid">
    <?php foreach ($libros as $libro): ?>
        <?php $sinStock = $libro->getStock() <= 0; ?>
        <article class="libro-card <?= $sinStock ? 'sin-stock' : '' ?>">
            <div class="libro-portada">
                <img src="img/portadas/<?= htmlspecialchars($libro->getImagen() ?: 'default.png') ?>"
                     alt="Portada de <?= htmlspecialchars($libro->getTitulo()) ?>" loading="lazy">
            </div>

            <div class="libro-info">
                <span class="badge <?= $libro->getGenero() === 'Sin género' ? 'text-bg-secondary' : 'text-bg-info' ?>"><?= htmlspecialchars($libro->getGenero()) ?></span>
                <h2 class="libro-titulo"><?= htmlspecialchars($libro->getTitulo()) ?></h2>
                <p class="libro-autor"><?= htmlspecialchars($libro->getAutor()) ?></p>
                <?php if (trim((string) $libro->getDescripcion()) !== ''): ?>
                    <p class="libro-desc"><?= htmlspecialchars($libro->getDescripcion()) ?></p>
                <?php endif; ?>
            </div>

            <div class="libro-stock">
                <?php if ($sinStock): ?>
                    <span class="badge text-bg-danger">Sin stock</span>
                    <span class="libro-cantidad stock-cero">Stock: 0</span>
                <?php else: ?>
                    <span class="badge text-bg-success">Disponible</span>
                    <span class="libro-cantidad">Stock: <?= $libro->getStock() ?></span>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
// Si la descripción es larga, se corta y aparece "Ver más".
document.querySelectorAll('.libro-desc').forEach(function (p) {
    if (p.scrollHeight <= p.clientHeight + 1) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'libro-mas';
    b.textContent = 'Ver más';
    b.addEventListener('click', function () {
        var abierta = p.classList.toggle('abierta');
        b.textContent = abierta ? 'Ver menos' : 'Ver más';
    });
    p.after(b);
});
</script>

<?php require __DIR__ . '/../../includes/paginador.php'; ?>
<?php require __DIR__ . '/../footer.php'; ?>
