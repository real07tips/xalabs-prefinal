<?php
class Socio  {
    private $id,  $nombre,  $vinculo,  $estado,  $telefono,  $email;
    public function __construct($id,  $nombre,  $vinculo,  $estado,  $telefono,  $email)  {
        $this->id=$id;
        $this->nombre=$nombre;
        $this->vinculo=$vinculo;
        $this->estado=$estado;
        $this->telefono=$telefono;
        $this->email=$email;
    }
    public function getId() {
        return $this->id;
    }
    public function getNroSocio() {
        return $this->id;
    }
    public function getNombre() {
        return $this->nombre;
    }
    public function getVinculo() {
        return $this->vinculo;
    }
    public function getEstado() {
        return $this->estado;
    }
    public function getTelefono() {
        return $this->telefono;
    }
    public function getEmail() {
        return $this->email;
    }
    // Arma el WHERE según los filtros: nombre, email, telefono y vinculo.
    private static function condiciones($filtros) {
        $sql = '';
        $datos = [];
        foreach (['nombre', 'email', 'telefono', 'vinculo'] as $campo) {
            $valor = trim((string)($filtros[$campo] ?? ''));
            if ($valor !== '') {
                $sql .= " AND $campo LIKE ?";
                $datos[] = '%' . addcslashes($valor, '%_\\') . '%';
            }
        }
        return [$sql, $datos];
    }

    public static function listar($pdo, $filtros = [], $limite = null, $offset = 0) {
        list($where, $datos) = self::condiciones($filtros);
        $sql = 'SELECT * FROM socios WHERE 1=1' . $where . ' ORDER BY nombre';
        if ($limite !== null) $sql .= ' LIMIT ' . max(1, (int)$limite) . ' OFFSET ' . max(0, (int)$offset);
        $s = $pdo->prepare($sql);
        $s->execute($datos);
        $lista = [];
        foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $f) $lista[] = new Socio($f['id'], $f['nombre'], $f['vinculo'], $f['estado'], $f['telefono'], $f['email']);
        return $lista;
    }

    public static function contar($pdo, $filtros = []) {
        list($where, $datos) = self::condiciones($filtros);
        $s = $pdo->prepare('SELECT COUNT(*) FROM socios WHERE 1=1' . $where);
        $s->execute($datos);
        return (int)$s->fetchColumn();
    }

    // Vínculos ya cargados, para sugerirlos en el filtro.
    public static function vinculos($pdo) {
        return $pdo->query("SELECT DISTINCT vinculo FROM socios WHERE vinculo <> '' ORDER BY vinculo")->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function buscarPorId($pdo, $id) {
        $s=$pdo->prepare('SELECT * FROM socios WHERE id=?');
        $s->execute([(int)$id]);
        $f=$s->fetch(PDO::FETCH_ASSOC);
        return $f?new Socio($f['id'], $f['nombre'], $f['vinculo'], $f['estado'], $f['telefono'], $f['email']):null;
    }

    public static function crear($pdo, $nombre, $vinculo, $estado, $telefono, $email) {
        $s=$pdo->prepare('INSERT INTO socios(nombre,vinculo,estado,telefono,email) VALUES(?,?,?,?,?)');
        return $s->execute([$nombre, $vinculo, $estado, $telefono, $email]);
    }

    public static function actualizar($pdo, $id, $nombre, $vinculo, $estado, $telefono, $email) {
        $s=$pdo->prepare('UPDATE socios SET nombre=?,vinculo=?,estado=?,telefono=?,email=? WHERE id=?');
        return $s->execute([$nombre, $vinculo, $estado, $telefono, $email, (int)$id]);
    }
    
    public static function eliminar($pdo, $id) {
        $s=$pdo->prepare('DELETE FROM socios WHERE id=?');
        return $s->execute([(int)$id]);
    }
}
