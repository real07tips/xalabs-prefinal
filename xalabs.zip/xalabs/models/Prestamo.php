<?php
class Prestamo  {
    private $id, $socioId, $libroId, $fechaPrestamo, $fechaDevolucion, $socioNombre, $libroTitulo;
    public function __construct($id, $socioId, $libroId, $fechaPrestamo, $fechaDevolucion, $socioNombre, $libroTitulo) {
        $this->id=$id;
        $this->socioId=$socioId;
        $this->libroId=$libroId;
        $this->fechaPrestamo=$fechaPrestamo;
        $this->fechaDevolucion=$fechaDevolucion;
        $this->socioNombre=$socioNombre;
        $this->libroTitulo=$libroTitulo;
    }
    public function getId() {
        return $this->id;
    }
    public function getSocioId() {
        return $this->socioId;
    }
    public function getLibroId() {
        return $this->libroId;
    }
    public function getFechaPrestamo() {
        return $this->fechaPrestamo;
    }
    public function getFechaDevolucion() {
        return $this->fechaDevolucion;
    }
    public function getSocioNombre() {
        return $this->socioNombre;
    }
    public function getLibroTitulo() {
        return $this->libroTitulo;
    }

    public static function listar($pdo, $limite = null, $offset = 0) {
        $sql='SELECT p.*,s.nombre AS socioNombre,l.titulo AS libroTitulo FROM prestamos p JOIN socios s ON s.id=p.socioId JOIN libros l ON l.id=p.libroId ORDER BY p.fechaPrestamo DESC';
        if ($limite !== null) $sql .= ' LIMIT ' . max(1, (int)$limite) . ' OFFSET ' . max(0, (int)$offset);
        $filas=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $lista=[];
        foreach($filas as $f)$lista[]=new Prestamo($f['id'], $f['socioId'], $f['libroId'], $f['fechaPrestamo'], $f['fechaDevolucion'], $f['socioNombre'], $f['libroTitulo']);
        return $lista;
    }

    public static function contar($pdo) { return (int)$pdo->query('SELECT COUNT(*) FROM prestamos')->fetchColumn(); 
    
    }

    public static function buscar($pdo, $id) {
        $s=$pdo->prepare('SELECT p.*,s.nombre AS socioNombre,l.titulo AS libroTitulo FROM prestamos p JOIN socios s ON s.id=p.socioId JOIN libros l ON l.id=p.libroId WHERE p.id=?');
        $s->execute([$id]);
        $f=$s->fetch(PDO::FETCH_ASSOC);
        return $f?new Prestamo($f['id'], $f['socioId'], $f['libroId'], $f['fechaPrestamo'], $f['fechaDevolucion'], $f['socioNombre'], $f['libroTitulo']):null;
    }

    public static function crear($pdo, $socioId, $libroId, $fechaPrestamo, $fechaDevolucion) {
        $s=$pdo->prepare('INSERT INTO prestamos(socioId,libroId,fechaPrestamo,fechaDevolucion) VALUES(?,?,?,?)');
        return $s->execute([$socioId, $libroId, $fechaPrestamo, $fechaDevolucion]);
    }

    public static function editar($pdo, $id, $socioId, $libroId, $fechaPrestamo, $fechaDevolucion) {
        $s=$pdo->prepare('UPDATE prestamos SET socioId=?,libroId=?,fechaPrestamo=?,fechaDevolucion=? WHERE id=?');
        return $s->execute([$socioId, $libroId, $fechaPrestamo, $fechaDevolucion, $id]);
    }

    public static function eliminar($pdo, $id) {
        $s=$pdo->prepare('DELETE FROM prestamos WHERE id=?');
        return $s->execute([$id]);
    }
}
