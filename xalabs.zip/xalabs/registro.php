<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['usuario_id'])) {
    header('Location: ' . (($_SESSION['rol'] ?? 'consulta') === 'consulta' ? 'catalogo.php' : 'index.php?accion=listar'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Solicitar registro - Biblioteca UTU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    <div class="card p-4" style="max-width: 430px; width: 100%;">
        <h4 class="text-center mb-3">Solicitar registro</h4>
        <p class="text-muted text-center">La cuenta nueva tendrá permisos de consulta.</p>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST" action="index.php?accion=registrar">
            <div class="mb-3">
                <label class="form-label">Nombre completo</label>
                <input type="text" name="nombre" class="form-control" required maxlength="100" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Correo electrónico</label>
                <input type="email" name="email" class="form-control" required maxlength="150" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña (mínimo 8 caracteres)</label>
                <input type="password" name="contrasena" class="form-control" required minlength="8" autocomplete="new-password">
            </div>
            <div class="mb-3">
                <label class="form-label">Repetir contraseña</label>
                <input type="password" name="confirmar" class="form-control" required minlength="8" autocomplete="new-password">
            </div>
            <button type="submit" class="btn btn-success w-100">Enviar solicitud</button>
        </form>
        <p class="text-center mt-3 mb-0"><a href="index.php?accion=login">Volver al inicio de sesión</a></p>
        <p class="text-center mt-2 mb-0"><a href="catalogo.php">← Volver al catálogo</a></p>
    </div>
</div>
</body>
</html>
