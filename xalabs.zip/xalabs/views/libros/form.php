<?php require __DIR__ . '/../header.php'; ?>

<h1 class="h3 mb-3">
    <?= isset($libro) ? 'Editar libro' : 'Nuevo libro' ?>
</h1>

<?php if (isset($error)): ?>
    <div class="alert alert-danger">
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($libro) ? 'editar' : 'crear' ?>"
      enctype="multipart/form-data"
      class="col-md-6">

    <?php if (isset($libro)): ?>
        <input type="hidden" name="id" value="<?= (int) $libro->getId() ?>">
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label">Código</label>
        <input type="text" name="codigo" class="form-control" required
               value="<?= htmlspecialchars($_POST['codigo'] ?? (isset($libro) ? $libro->getCodigo() : '')) ?>">
    </div>

    <div class="mb-3">
        <label class="form-label">Título</label>
        <input type="text" name="titulo" class="form-control" required
               value="<?= htmlspecialchars($_POST['titulo'] ?? (isset($libro) ? $libro->getTitulo() : '')) ?>">
    </div>

    <div class="mb-3">
        <label class="form-label">Autor</label>
        <input type="text" name="autor" class="form-control" list="autores" required maxlength="150"
               value="<?= htmlspecialchars($_POST['autor'] ?? (isset($libro) ? $libro->getAutor() : '')) ?>">
        <datalist id="autores">
            <?php foreach ($autores as $autor): ?>
                <option value="<?= htmlspecialchars($autor->getNombre()) ?>">
            <?php endforeach; ?>
        </datalist>
    </div>

    <div class="mb-3">
        <label class="form-label">Género</label>
        <input type="text" name="genero" class="form-control" required
               value="<?= htmlspecialchars($_POST['genero'] ?? (isset($libro) ? $libro->getGenero() : '')) ?>">
    </div>

    <div class="mb-3">
        <label class="form-label">Descripción</label>
        <textarea name="descripcion" class="form-control" rows="3"><?= htmlspecialchars($_POST['descripcion'] ?? (isset($libro) ? $libro->getDescripcion() : '')) ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Stock</label>
        <input type="number" name="stock" min="0" class="form-control" required
               value="<?= htmlspecialchars($_POST['stock'] ?? (isset($libro) ? $libro->getStock() : '1')) ?>">
    </div>

    <div class="mb-3">
        <label class="form-label">Portada</label>
        <input type="file" name="imagen" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif">
        <?php if (isset($libro) && $libro->getImagen()): ?>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary">Guardar</button>
    <a href="index.php?accion=listar" class="btn btn-secondary">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>
