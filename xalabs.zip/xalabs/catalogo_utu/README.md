# Prototipo complementario — Biblioteca Institucional UTU

Este directorio `catalogo_utu` es una aplicación independiente que complementa el MVC original.

## Qué hace

- Catálogo de libros desde la tabla `libros` de la base `biblioteca`.
- Búsqueda por título, autor o género.
- Filtro por género y disponibilidad.
- Ficha detallada de cada libro.
- Búsqueda inteligente local mediante lenguaje natural.
- Diseño responsive.
- Manifest + Service Worker para comportamiento PWA.
- No crea, edita ni elimina libros, préstamos, socios ni usuarios.

## Estructura

- `index.php`: interfaz principal.
- `api/libros.php`: endpoint JSON de solo lectura.
- `assets/css/app.css`: identidad visual y responsive.
- `assets/js/app.js`: filtros, búsqueda inteligente, fichas y PWA.
- `assets/img/`: portadas reales copiadas del proyecto original.
- `assets/img/logo-utu-placeholder.png`: reemplazar por el logo UTU entregado por el docente.
- `manifest.json`: configuración PWA.
- `sw.js`: cache básico de la aplicación.

## Datos

La app usa la conexión de `../conexion.php` y consulta únicamente:

`SELECT id, titulo, autor, genero, stock, imagen FROM libros ORDER BY titulo`

Por eso no inventa libros y refleja los datos existentes.

## Instalación local con XAMPP

1. Copiar la carpeta `xalabs1` dentro de `htdocs`.
2. Importar `biblioteca.sql` en phpMyAdmin si todavía no existe la base `biblioteca`.
3. Verificar `conexion.php` con la configuración local de MySQL.
4. Abrir:
   `http://localhost/xalabs1/catalogo_utu/`
5. Para instalar el logo institucional, reemplazar:
   `assets/img/logo-utu-placeholder.png`
   por el archivo del logo proporcionado por el docente (manteniendo ese nombre), o cambiar las referencias si se desea conservar otro nombre.

## Importante

No se modificaron los archivos del sistema MVC original. El prototipo solo reutiliza su conexión y lee la tabla `libros`.
