<?php
require_once __DIR__ . '/../../conexion.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $sql = "SELECT l.id, l.titulo, a.nombre AS autor, l.genero, l.stock, l.imagen, l.descripcion FROM libros l JOIN autores a ON a.id = l.autor_id ORDER BY l.titulo ASC";
    $stmt = $pdo->query($sql);
    $libros = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $genres = [];
    foreach ($libros as &$libro) {
        $libro['id'] = (int)$libro['id'];
        $libro['stock'] = (int)$libro['stock'];
        $libro['disponible'] = $libro['stock'] > 0;
        $libro['imagen_url'] = 'assets/img/' . rawurlencode(basename($libro['imagen']));
        if ($libro['genero'] !== '' && !in_array($libro['genero'], $genres, true)) {
            $genres[] = $libro['genero'];
        }
    }
    unset($libro);

    echo json_encode([
        'ok' => true,
        'total' => count($libros),
        'generos' => $genres,
        'libros' => $libros
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'No fue posible consultar el catálogo.'
    ], JSON_UNESCAPED_UNICODE);
}
