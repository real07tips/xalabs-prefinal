<?php
session_start();
require __DIR__ . '/controllers/LibroController.php';
require __DIR__ . '/controllers/SocioController.php';
require __DIR__ . '/controllers/PrestamoController.php';
require __DIR__ . '/controllers/UsuarioController.php';
require __DIR__ . '/controllers/AuthController.php';

// La primera vista de la app es el catálogo público.
$accion = $_GET['accion'] ?? 'catalogo';

// Estas pantallas se pueden abrir sin iniciar sesión.
if (in_array($accion, ['catalogo', 'login', 'autenticar', 'registro', 'registrar'], true)) {
    switch ($accion) {
        case 'catalogo':
            catalogoPublico();
            break;
        case 'login':
            formLogin();
            break;
        case 'autenticar':
            login();
            break;
        case 'registro':
            formRegistro();
            break;
        case 'registrar':
            registrarUsuario();
            break;
    }
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php?accion=login');
    exit;
}

// Cada rol puede entrar solo a las secciones permitidas.
$rol = $_SESSION['rol'] ?? 'consulta';
$accionesAdmin = ['listarUsuarios', 'formCrearUsuario', 'crearUsuario', 'formEditarUsuario', 'editarUsuario', 'eliminarUsuario'];
$accionesBiblioteca = ['listar', 'formCrear', 'crear', 'formEditar', 'editar', 'eliminar', 'listarSocios', 'formCrearSocio', 'crearSocio', 'formEditarSocio', 'editarSocio', 'eliminarSocio', 'listarPrestamos', 'formCrearPrestamo', 'crearPrestamo', 'formEditarPrestamo', 'editarPrestamo', 'eliminarPrestamo'];

if (in_array($accion, $accionesAdmin, true) && $rol !== 'administrador') {
    http_response_code(403);
    exit('No tenés permiso para administrar usuarios.');
}

if (in_array($accion, $accionesBiblioteca, true) && !in_array($rol, ['administrador', 'bibliotecario'], true)) {
    http_response_code(403);
    exit('Tu usuario solo tiene permisos de consulta.');
}

switch ($accion) {
    // LIBROS
    case 'listar':
        listarLibros();
        break;
    case 'formCrear':
        formCrearLibro();
        break;
    case 'crear':
        crearLibro();
        break;
    case 'formEditar':
        formEditarLibro();
        break;
    case 'editar':
        editarLibro();
        break;
    case 'eliminar':
        eliminarLibro();
        break;

    // SOCIOS
    case 'listarSocios':
        listarSocios();
        break;
    case 'formCrearSocio':
        formCrearSocio();
        break;
    case 'crearSocio':
        crearSocio();
        break;
    case 'formEditarSocio':
        formEditarSocio();
        break;
    case 'editarSocio':
        editarSocio();
        break;
    case 'eliminarSocio':
        eliminarSocio();
        break;

    // PRESTAMOS
    case 'listarPrestamos':
        listarPrestamos();
        break;
    case 'formCrearPrestamo':
        formCrearPrestamo();
        break;
    case 'crearPrestamo':
        crearPrestamo();
        break;
    case 'formEditarPrestamo':
        formEditarPrestamo();
        break;
    case 'editarPrestamo':
        editarPrestamo();
        break;
    case 'eliminarPrestamo':
        eliminarPrestamo();
        break;

    // USUARIOS
    case 'listarUsuarios':
        listarUsuarios();
        break;
    case 'formCrearUsuario':
        formCrearUsuario();
        break;
    case 'crearUsuario':
        crearUsuario();
        break;
    case 'formEditarUsuario':
        formEditarUsuario();
        break;
    case 'editarUsuario':
        editarUsuario();
        break;
    case 'eliminarUsuario':
        eliminarUsuario();
        break;

    case 'logout':
        logout();
        break;

    default:
        http_response_code(404);
        echo 'Página no encontrada';
}
