const state = {
  books: [],
  filtered: []
};

const $ = (s) => document.querySelector(s);

function normalize(text) {
  return (text || '').toString().normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

async function loadBooks() {
  const res = await fetch('api/libros.php', {headers: {'Accept': 'application/json'}});
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'Error');
  state.books = data.libros;
  populateGenres(data.generos);
  applyFilters();
}

function populateGenres(genres) {
  const select = $('#genre');
  [...genres].sort((a,b) => a.localeCompare(b, 'es')).forEach(g => {
    const option = document.createElement('option');
    option.value = g;
    option.textContent = g;
    select.appendChild(option);
  });
}

function applyFilters(list = null) {
  const q = normalize($('#search').value);
  const genre = $('#genre').value;
  const availability = $('#availability').value;

  let books = list ?? state.books;
  books = books.filter(book => {
    const haystack = normalize(`${book.titulo} ${book.autor} ${book.genero}`);
    const textOK = !q || haystack.includes(q);
    const genreOK = !genre || book.genero === genre;
    const availabilityOK =
      !availability ||
      (availability === 'available' && book.disponible) ||
      (availability === 'unavailable' && !book.disponible);
    return textOK && genreOK && availabilityOK;
  });

  state.filtered = books;
  renderBooks(books);
}

function renderBooks(books) {
  $('#resultCount').textContent = `${books.length} ${books.length === 1 ? 'resultado' : 'resultados'}`;
  $('#empty').hidden = books.length !== 0;
  $('#catalog').innerHTML = books.map(book => `
    <article class="book-card">
      <div class="cover-wrap">
        <img src="${escapeAttr(book.imagen_url)}" alt="Portada de ${escapeHtml(book.titulo)}" loading="lazy"
             onerror="this.src='assets/img/logo-utu-placeholder.png'">
      </div>
      <div class="book-body">
        <span class="genre">${escapeHtml(book.genero)}</span>
        <h3>${escapeHtml(book.titulo)}</h3>
        <p class="author">${escapeHtml(book.autor)}</p>
        <div class="book-bottom">
          <span class="availability ${book.disponible ? 'yes' : 'no'}">
            ${book.disponible ? `● Disponible · ${book.stock}` : '● No disponible'}
          </span>
          <button class="btn btn-outline" data-id="${book.id}">Ver ficha</button>
        </div>
      </div>
    </article>
  `).join('');
}

function smartSearch(query) {
  const raw = normalize(query);
  if (!raw) {
    $('#smartHelp').textContent = 'Escribí qué libro necesitás.';
    return;
  }

  // Interpretación local, sin API externa ni credenciales.
  const wantsAvailable = /(disponible|disponibles|hay|para prestar|en stock)/.test(raw);
  const wantsUnavailable = /(no disponible|agotado|prestado)/.test(raw);
  const genreWords = state.books.map(b => normalize(b.genero)).filter(Boolean);
  const detectedGenre = genreWords.find(g => raw.includes(g));

  // Remove natural-language filler before matching titles/authors.
  const cleaned = raw
    .replace(/\b(libro|libros|busco|buscar|quiero|necesito|de|del|la|el|un|una|algo|sobre|para|que|haya|disponible|disponibles|en|stock)\b/g, ' ')
    .replace(/\s+/g, ' ').trim();

  let results = state.books.filter(book => {
    const text = normalize(`${book.titulo} ${book.autor} ${book.genero}`);
    const availabilityOK =
      wantsAvailable ? book.disponible :
      wantsUnavailable ? !book.disponible : true;
    const genreOK = detectedGenre ? normalize(book.genero) === detectedGenre : true;
    const textOK = !cleaned || text.includes(cleaned) ||
      cleaned.split(' ').filter(Boolean).some(word => word.length >= 3 && text.includes(word));
    return availabilityOK && genreOK && textOK;
  });

  // If the query is a direct title/author and the filler-removal was too aggressive,
  // fall back to normal contains matching.
  if (!results.length) {
    results = state.books.filter(book => {
      const text = normalize(`${book.titulo} ${book.autor} ${book.genero}`);
      return text.includes(raw) && (!wantsAvailable || book.disponible) && (!wantsUnavailable || !book.disponible);
    });
  }

  $('#search').value = '';
  $('#genre').value = '';
  $('#availability').value = '';
  $('#smartHelp').textContent = results.length
    ? `Búsqueda interpretada: ${results.length} resultado(s).`
    : 'No encontré coincidencias en los datos disponibles.';
  renderBooks(results);
}

function showDetails(id) {
  const b = state.books.find(x => x.id === Number(id));
  if (!b) return;
  $('#modalContent').innerHTML = `
    <div class="detail">
      <img src="${escapeAttr(b.imagen_url)}" alt="Portada de ${escapeHtml(b.titulo)}">
      <div>
        <span class="kicker">Ficha del libro</span>
        <h2>${escapeHtml(b.titulo)}</h2>
        <p class="detail-author">${escapeHtml(b.autor)}</p>
        <p>${escapeHtml(b.descripcion || '')}</p>
        <dl>
          <div><dt>Género</dt><dd>${escapeHtml(b.genero)}</dd></div>
          <div><dt>Estado</dt><dd>${b.disponible ? 'Disponible' : 'No disponible'}</dd></div>
          <div><dt>Ejemplares</dt><dd class="${b.stock > 0 ? '' : 'stock-cero'}">${b.stock}</dd></div>
        </dl>
      </div>
    </div>`;
  $('#modal').hidden = false;
  document.body.classList.add('modal-open');
}

function escapeHtml(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function escapeAttr(v) { return escapeHtml(v); }

$('#smartForm').addEventListener('submit', e => {
  e.preventDefault();
  smartSearch($('#smartQuery').value);
});
document.querySelectorAll('.chip').forEach(btn => btn.addEventListener('click', () => {
  $('#smartQuery').value = btn.dataset.query;
  smartSearch(btn.dataset.query);
}));
['search','genre','availability'].forEach(id => {
  $('#' + id).addEventListener('input', () => applyFilters());
  $('#' + id).addEventListener('change', () => applyFilters());
});
$('#clearFilters').addEventListener('click', () => {
  $('#search').value = '';
  $('#genre').value = '';
  $('#availability').value = '';
  $('#smartHelp').textContent = 'La búsqueda inteligente interpreta términos de disponibilidad, género, autor y título usando únicamente los datos de la base.';
  applyFilters();
});
document.addEventListener('click', e => {
  const button = e.target.closest('[data-id]');
  if (button) showDetails(button.dataset.id);
  if (e.target.matches('[data-close]')) {
    $('#modal').hidden = true;
    document.body.classList.remove('modal-open');
  }
});

loadBooks().catch(() => {
  $('#resultCount').textContent = 'Error';
  $('#catalog').innerHTML = '<div class="error card">No se pudo conectar con la base de datos. Verificá XAMPP/Apache, MySQL y la configuración de <code>conexion.php</code>.</div>';
});
