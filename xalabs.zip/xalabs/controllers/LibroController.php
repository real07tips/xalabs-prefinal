<?php
require_once __DIR__ . '/../models/Libro.php';
require_once __DIR__ . '/../models/Autor.php';
require_once __DIR__ . '/../conexion.php';

function listarLibros() {
    global $pdo;
    $filtros = ['titulo' => trim($_GET['titulo'] ?? ''), 'autor' => trim($_GET['autor'] ?? ''), 'genero' => trim($_GET['genero'] ?? ''), 'codigo' => trim($_GET['codigo'] ?? '')];
    $porPagina = 10;
    $pagina = max(1, (int)($_GET['pagina'] ?? 1));
    $totalRegistros = Libro::contar($pdo, $filtros);
    $totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
    $pagina = min($pagina, $totalPaginas);
    $libros = Libro::listar($pdo, $filtros, $porPagina, ($pagina - 1) * $porPagina);
    require __DIR__ . '/../views/libros/listar.php';
}

function catalogoPublico() {
    global $pdo;
    $filtros = ['titulo' => trim($_GET['titulo'] ?? ''), 'autor' => trim($_GET['autor'] ?? ''), 'genero' => trim($_GET['genero'] ?? '')];
    $porPagina = 12;
    $pagina = max(1, (int)($_GET['pagina'] ?? 1));
    $totalRegistros = Libro::contar($pdo, $filtros);
    $totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
    $pagina = min($pagina, $totalPaginas);
    $libros = Libro::listar($pdo, $filtros, $porPagina, ($pagina - 1) * $porPagina);
    require __DIR__ . '/../views/libros/catalogo.php';
}

function formCrearLibro() {
    global $pdo;
    $autores = Autor::listar($pdo);
    require __DIR__ . '/../views/libros/form.php';
}

function crearLibro() {
    global $pdo;
    $codigo = trim($_POST['codigo'] ?? '');
    $titulo = trim($_POST['titulo'] ?? '');
    $autorNombre = trim($_POST['autor'] ?? '');
    $genero = trim($_POST['genero'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $stock = filter_var($_POST['stock'] ?? '', FILTER_VALIDATE_INT);
    $autores = Autor::listar($pdo);

    if ($codigo === '' || $titulo === '' || $autorNombre === '' || $genero === '' || $stock === false || $stock < 0) {
        $error = 'Completá los campos correctamente.';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }
    $imagen = guardarImagenSubida();
    if ($imagen === false) {
        $error = 'La imagen no es válida o supera los 2 MB.';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }
    $autorId = Autor::buscarOCrear($pdo, $autorNombre);
    try {
        Libro::crear($pdo, $codigo, $titulo, $autorId, $genero, $stock, $imagen ?? 'default.png', $descripcion);
    } catch (PDOException $e) {
        $error = 'No se pudo guardar. Revisá que el código no esté repetido.';
        $autores = Autor::listar($pdo);
        require __DIR__ . '/../views/libros/form.php';
        return;
    }
    header('Location: index.php?accion=listar'); exit;
}

function formEditarLibro() {
    global $pdo;
    $libro = Libro::buscarPorId($pdo, $_GET['id'] ?? 0);
    if (!$libro) { header('Location: index.php?accion=listar'); exit; }
    $autores = Autor::listar($pdo);
    require __DIR__ . '/../views/libros/form.php';
}

function editarLibro() {
    global $pdo;
    $id = (int)($_POST['id'] ?? 0);
    $libro = Libro::buscarPorId($pdo, $id);
    if (!$libro) { header('Location: index.php?accion=listar'); exit; }
    $codigo = trim($_POST['codigo'] ?? '');
    $titulo = trim($_POST['titulo'] ?? '');
    $autorNombre = trim($_POST['autor'] ?? '');
    $genero = trim($_POST['genero'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $stock = filter_var($_POST['stock'] ?? '', FILTER_VALIDATE_INT);
    $autores = Autor::listar($pdo);
    if ($codigo === '' || $titulo === '' || $autorNombre === '' || $genero === '' || $stock === false || $stock < 0) {
        $error = 'Completá los campos correctamente.';
        require __DIR__ . '/../views/libros/form.php'; return;
    }
    $imagenNueva = guardarImagenSubida();
    if ($imagenNueva === false) {
        $error = 'La imagen no es válida o supera los 2 MB.';
        require __DIR__ . '/../views/libros/form.php'; return;
    }
    $autorId = Autor::buscarOCrear($pdo, $autorNombre);
    try {
        Libro::actualizar($pdo, $id, $codigo, $titulo, $autorId, $genero, $stock, $imagenNueva ?? $libro->getImagen(), $descripcion);
    } catch (PDOException $e) {
        $error = 'No se pudo guardar. Revisá que el código no esté repetido.';
        require __DIR__ . '/../views/libros/form.php'; return;
    }
    header('Location: index.php?accion=listar'); exit;
}

function eliminarLibro() {
    global $pdo;
    Libro::eliminar($pdo, (int)($_GET['id'] ?? 0));
    header('Location: index.php?accion=listar'); exit;
}

function guardarImagenSubida() {
    if (!isset($_FILES['imagen']) || $_FILES['imagen']['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($_FILES['imagen']['error'] !== UPLOAD_ERR_OK || $_FILES['imagen']['size'] > 2 * 1024 * 1024) return false;
    if (@getimagesize($_FILES['imagen']['tmp_name']) === false) return false;
    $extension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ['jpg','jpeg','png','gif','webp'], true)) return false;
    $nombre = uniqid('portada_', true) . '.' . $extension;
    return move_uploaded_file($_FILES['imagen']['tmp_name'], __DIR__ . '/../img/portadas/' . $nombre) ? $nombre : false;
}
